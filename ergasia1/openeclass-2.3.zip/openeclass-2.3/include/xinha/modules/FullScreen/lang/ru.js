﻿// I18N constants
// LANG: "ru", ENCODING: UTF-8
// Author: Andrei Blagorazumov, a@fnr.ru
{
  "Maximize/Minimize Editor": "Развернуть/Свернуть редактор"
};