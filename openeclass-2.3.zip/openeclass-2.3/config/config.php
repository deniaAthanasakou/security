<?php
/* ========================================================
 * OpeneClass 2.2 configuration file
 * Automatically created by install on 2018-04-15 12:17
 * ======================================================== */

$urlServer = "http://localhost/openeclass-2.3/";
$urlAppend = "/openeclass-2.3";
$webDir    = "C:/wamp/www/openeclass-2.3/" ;

$mysqlServer = "localhost";
$mysqlUser = "root";
$mysqlPassword = "";
$mysqlMainDb = "eclass";
$phpMyAdminURL = "../admin/mysql/";
$phpSysInfoURL = "../admin/sysinfo/";
$emailAdministrator = "tempuser25252@gmail.com";
$administratorName = "Διαχειριστής";
$administratorSurname = "Πλατφόρμας";
$siteName = "Open eClass";

$telephone = "+30 2xx xxxx xxx";
$fax = "";
$emailhelpdesk = "tempuser25252@gmail.com";

$language = "greek";

$Institution = "Ακαδημαϊκό Διαδίκτυο GUNet ";
$InstitutionUrl = "http://www.gunet.gr/";
$postaddress = "";

$have_latex = FALSE;
$close_user_registration = FALSE;

$persoIsActive = TRUE;
$durationAccount = "126144000";

define("UTF8", true);


$encryptedPasswd = true;
