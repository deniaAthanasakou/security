<?php
                session_start();
        $dbname="TMB100";
        session_register("dbname");
        include("../../modules/course_home/course_home.php");
        ?>