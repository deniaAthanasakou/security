<?php
                session_start();
        $dbname="TMC100";
        session_register("dbname");
        include("../../modules/course_home/course_home.php");
        ?>