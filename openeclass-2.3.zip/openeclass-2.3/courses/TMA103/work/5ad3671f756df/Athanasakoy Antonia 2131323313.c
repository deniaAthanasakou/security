#include <stdio.h>
#include <math.h>
#define MAXNUMB 100000000

int main(void)														
{
	int number , mask , i , k , j , pshfia , max , temp , temp1 , sub , pl;			//dhlosh metablhton
	int counter;						//metrame an yparxei enas parapano diaireths tou number ektos apo to 1
	int flag;						//gia flag=0 den koitame an yparxoun alles ypakolou8ies allios 1 gia sunexeia
	int flag1;						//gia flag1=0 koitame an h ypakolou8ia exei diairetes allios 1 an oxi
	int flag3;						//gia flag3=1 bgainoume apo to loop ki pame ston epomeno ari8mo-number,an den einai protos
	int counter2;						//blepoume an oi upakolou8ies den einai protoi gia counter2=1
	for( number = 11; number <= MAXNUMB ; number = number + 2 )		
	{
			temp1 = number;								//prota briskoume tis upakolou8ies
			max = 1;
			pshfia = 0;
			k = 1;
			while( temp1 != 0 )							//blepoume posa pshfia exei o ari8mos
			{
				temp1 = temp1 / 10;
				pshfia ++ ;
			}
			while( k <= pshfia )							//analoga me ta posa einai briskoume to plh8os ton upoakolou8ion 
			{
				max = max * 2;
				k++;
			}
			flag = 1;
			for( j = 1 ; j < max - 1 && flag == 1 ; j ++ )				//briskoume tis upakolou8ies me thn me8odo tou mask,sub:upakolou8ia
			{
				mask = j;
				sub = 0;
				pl = 1;
				temp = number;
				while( temp != 0 )						//enoso o ari8mos einai diaforos tou mhdenos
				{
					if( mask % 2 == 1 )					//an to mod tou mask me to 2 einai ena tote to sub einai to a8roisma tou idiou 
					{
						sub = sub + (temp % 10) * pl;			//kai tou mod tou ari8mou me to 10 epi to pl to opoio epeita auksanetai
						pl = pl * 10;
					}
					temp = temp / 10;					
					mask = mask / 2;					
				}
				flag1 = 0;
				counter2 = 1;
				if( sub == 1 || sub == 4 || sub == 6 || sub == 8 || sub == 9 || sub == 0 )	//an to sub einai ena apo auta tote pame sthn epomenh upakolou8ia
				{
					counter2 = 1;								
					flag1 = 1;
				}
				for( k = 2 ; k <= sqrt( sub ) && flag1 == 0 && sub != 1 ; k++ )			//an den einai tote mpainoume se loop gia na doume an einai proth h oxi
				{
					if(sub % k == 0)							//an den einai bgainoume apo to loop me thn boh8eia tou flag1
					{
						flag1 = 1;
						flag = 1;			
					}
					else  				//allios
					{
						flag1 = 0;		//sunexizoume mexri na bre8ei diaireths
					}
				}					//an den bre8ei	tote den anazhtame allo gia ypakolou8ies kai ara pame ston epomeno ari8mo
				if( flag1 == 0 )
				{
					flag = 0;
					counter2 = 0;			//an den bre8ei tote exoume to counter2 na einai 0 etsi oste autos o ari8mos na mhn einai minimal prime
				}
			}
			if(counter2 == 1)						//blepoume an einai ki protos an oi upakolou8ies tou den einai protoi
			{
				flag3 = 0;
				for( i = 2 ; i <= sqrt( number ) && flag3 == 0 ; i ++ )
				{
					if(number % i == 0)					//an  diaireitai me enan ari8mo!=1 ki <= tou tetragonou tou idiou tote auksanoume ton 
					{
						flag3 = 1;							//metrhth kata ena ki bgainoume apo to for afou exei esto ki enan diaireth
						counter = 1 ;							//diaforo tou 1
					}
					else 
					{
						counter = 0;
						flag3 = 0;
					}
				}
			}
			if(counter == 0 && counter2 == 1)					
			{
				printf( "%d\n" , number);
			}
			
	}
	return 0;
}
