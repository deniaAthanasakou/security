<?php
                session_start();
        $dbname="TMA104";
        session_register("dbname");
        include("../../modules/course_home/course_home.php");
        ?>